data:extend({
	{
		type = "item",
		name = "ping-tool",
		icon = "__Map Ping__/graphics/PingTool.png",
		flags = {"goes-to-quickbar"},
		place_result = "ping-tool",
		subgroup = "capsule",
		order = "c[target]",
		stack_size = 1,
	}
})