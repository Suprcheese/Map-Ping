require "util"

script.on_init(function() On_Init() end)
script.on_configuration_changed(function() On_Init() end)
script.on_load(function() On_Load() end)

function On_Init()
	global.arrows = global.arrows or {}
end

function On_Load()
	if global.ticker then
		script.on_event(defines.events.on_tick, process_tick)
	end
end

script.on_event(defines.events.on_player_cursor_stack_changed, function(event)
	local player = game.players[event.player_index]
	if isHolding({name="ping-tool", count=1}, player) then
		player.character_build_distance_bonus = 500
	else
		player.character_build_distance_bonus = 0
	end
	if global.ticker and not isHolding({name="ping-tool", count=1}, player) then
		global.ticker[player.index] = false
		local found = false
		for i, p in pairs(game.players) do
			if global.ticker[p.index] then
				found = true
			end
		end
		if not found then
			global.ticker = nil
		end
	end
end)

function process_tick()
	if game.tick % 30 == 20 then
		if global.ticker then
			for i, player in pairs(game.players) do
				if global.ticker[player.index] then
					if global.arrows[player.index] and global.arrows[player.index].valid then
						global.arrows[player.index].destroy()
						global.arrows[player.index] = nil
					end
					if player.selection then
						local arrow = player.surface.create_entity({name = "ping-arrow-entity", position = player.selected.position, force = player.force})
						arrow.color = player.color
						global.arrows[player.index] = arrow
					end
				end
			end
			return
		end
		script.on_event(defines.events.on_tick, nil)
	end
end

function playSoundForForce(sound, force)
	for i, player in pairs(force.players) do
		if player.connected then
			player.surface.create_entity({name = sound, position = player.position})
		end
	end
end

-- function playSoundForAllPlayers(sound)
	-- for i, player in pairs(game.players) do
		-- if player.connected then
			-- player.surface.create_entity({name = sound, position = player.position})
		-- end
	-- end
-- end

function isHolding(stack, player)
	local holding = player.cursor_stack
	if holding and holding.valid_for_read and (holding.name == stack.name) and (holding.count >= stack.count) then
		return true
	end
	return false
end

function pingLocation(position, player)
	local current_tick = game.tick
	if global.tick and global.tick > current_tick then
		return
	end
	global.tick = current_tick + lockoutTicks
	local ping = player.surface.create_entity({name = "map-ping-explosion", position = position})
	local marker = player.surface.create_entity({name = "map-ping-marker", position = position, force = player.force})
	marker.backer_name = player.name .. "'s ping location"
	-- player.force.print({"pinged-location", player.name})
	playSoundForForce("ping-sound", player.force)
end

script.on_event(defines.events.on_built_entity, function(event)
	local player = game.players[event.player_index]
	local entity = event.created_entity
	if entity.name == "entity-ghost" then
		if entity.ghost_name == "ping-tool" then
			global.ticker = global.ticker or {}
			global.ticker[event.player_index] = true
			player.print({"entered-selection-mode"})
			return entity.destroy()
		end
	end
	if entity.name == "ping-tool" then
		player.insert({name="ping-tool", count=1})
		pingLocation(entity.position, player)
		return entity.destroy()
	end
end)
