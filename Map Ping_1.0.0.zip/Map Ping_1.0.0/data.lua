require("config")
require("prototypes.items")
require("prototypes.entities")
require("prototypes.sounds")

-- data:extend({
  -- {
    -- type = "custom-input",
    -- name = "ion-cannon-hotkey",
    -- key_sequence = "I",
    -- consuming = "script-only"
  -- }
-- })